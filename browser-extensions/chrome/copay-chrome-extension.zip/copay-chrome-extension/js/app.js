'use strict';

angular.module('cosign',[
  'ngRoute',
]);
