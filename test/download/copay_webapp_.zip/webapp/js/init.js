'use strict';
var copay = require('copay');
angular.element(document).ready(function() {
  // Init the app
  angular.bootstrap(document, ['copay']);
});
