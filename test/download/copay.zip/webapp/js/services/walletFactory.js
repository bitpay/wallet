'use strict';

angular.module('copay.walletFactory').value('walletFactory', new copay.WalletFactory(config, copay.version));

