Run `node browser/build.js -a` in the repository's root directory before using those examples.
