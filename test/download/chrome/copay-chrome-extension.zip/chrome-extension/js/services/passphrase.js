'use strict';

angular.module('copay.passphrase').value('Passphrase', new copay.Passphrase(config.passphrase));
